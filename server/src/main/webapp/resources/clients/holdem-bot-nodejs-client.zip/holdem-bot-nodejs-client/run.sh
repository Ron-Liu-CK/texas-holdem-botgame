#!/bin/sh

node play.js
