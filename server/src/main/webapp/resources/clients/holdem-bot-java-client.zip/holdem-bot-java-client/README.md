texas-holdem-javabot
====================

An example bot player for Texas Hold'em implemented in Java

