#!/usr/bin/env python


class Room(object):
    """ generated source for enum Room """
    TRAINING = 'TRAINING'
    TOURNAMENT = 'TOURNAMENT'
    FREEPLAY = 'FREEPLAY'

