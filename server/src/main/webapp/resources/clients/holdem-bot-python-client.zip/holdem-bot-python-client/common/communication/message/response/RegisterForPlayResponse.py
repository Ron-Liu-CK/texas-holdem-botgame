#!/usr/bin/env python

from TexasResponse import TexasResponse


class RegisterForPlayResponse(TexasResponse):
    """ generated source for class RegisterForPlayResponse """
    sessionId = str()

