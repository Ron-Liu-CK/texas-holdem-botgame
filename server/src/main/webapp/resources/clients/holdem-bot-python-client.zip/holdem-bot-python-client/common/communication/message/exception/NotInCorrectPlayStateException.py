#!/usr/bin/env python
""" generated source for module NotInCorrectPlayStateException """
# package: se.cygni.texasholdem.communication.message.exception
import se.cygni.texasholdem.communication.message.type_.IsATexasMessage

class NotInCorrectPlayStateException(TexasException):
    """ generated source for class NotInCorrectPlayStateException """
    def throwException(self):
        """ generated source for method throwException """
        raise se.cygni.texasholdem.game.exception.NotInCorrectPlayStateException(message)

