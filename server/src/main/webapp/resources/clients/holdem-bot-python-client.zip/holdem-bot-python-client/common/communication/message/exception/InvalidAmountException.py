#!/usr/bin/env python
""" generated source for module InvalidAmountException """
# package: se.cygni.texasholdem.communication.message.exception
import se.cygni.texasholdem.communication.message.type_.IsATexasMessage

class InvalidAmountException(TexasException):
    """ generated source for class InvalidAmountException """
    def throwException(self):
        """ generated source for method throwException """
        raise se.cygni.texasholdem.game.exception.InvalidAmountException(message)

