#!/usr/bin/env python
""" generated source for module GameException """
# package: se.cygni.texasholdem.communication.message.exception
import se.cygni.texasholdem.communication.message.type_.IsATexasMessage

class GameException(TexasException):
    """ generated source for class GameException """
    def throwException(self):
        """ generated source for method throwException """
        raise se.cygni.texasholdem.game.exception.GameException(message)

