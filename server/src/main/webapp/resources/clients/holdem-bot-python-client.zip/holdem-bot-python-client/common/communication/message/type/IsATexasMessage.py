#!/usr/bin/env python


class IsATexasMessage:
    def __init__(self):
        """ generated source for method __init__ """

    def __call__(self, obj):
        """ generated source for method __call__ """
        setattr(obj, self.__class__.__name__, self)
        return obj

