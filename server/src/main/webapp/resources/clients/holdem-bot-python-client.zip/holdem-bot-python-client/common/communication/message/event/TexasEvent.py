#!/usr/bin/env python

from common.communication.message.TexasMessage import TexasMessage


class TexasEvent(TexasMessage):
    """ generated source for class TexasEvent """

