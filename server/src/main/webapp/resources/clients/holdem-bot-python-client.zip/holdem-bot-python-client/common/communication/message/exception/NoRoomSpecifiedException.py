#!/usr/bin/env python
""" generated source for module NoRoomSpecifiedException """
# package: se.cygni.texasholdem.communication.message.exception
import se.cygni.texasholdem.communication.message.type_.IsATexasMessage

class NoRoomSpecifiedException(TexasException):
    """ generated source for class NoRoomSpecifiedException """
    def throwException(self):
        """ generated source for method throwException """
        raise se.cygni.texasholdem.game.exception.NoRoomSpecifiedException(message)

