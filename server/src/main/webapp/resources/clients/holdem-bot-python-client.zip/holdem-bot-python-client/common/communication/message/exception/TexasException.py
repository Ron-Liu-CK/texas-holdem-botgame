#!/usr/bin/env python
""" generated source for module TexasException """
# package: se.cygni.texasholdem.communication.message.exception
import se.cygni.texasholdem.communication.message.response.TexasResponse

class TexasException(TexasResponse):
    """ generated source for class TexasException """
    message = str()

    def throwException(self):
        """ generated source for method throwException """

