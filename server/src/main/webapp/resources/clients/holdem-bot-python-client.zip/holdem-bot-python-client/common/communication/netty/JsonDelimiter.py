#!/usr/bin/env python


class JsonDelimiter(object):
    """ generated source for class JsonDelimiter """
    def __init__(self):
        """ generated source for method __init__ """

    @staticmethod
    def delimiter():
        """ generated source for method delimiter """
        return "_-^emil^-_"

